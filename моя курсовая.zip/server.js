import express from 'express'
import cookieParser from 'cookie-parser'
import { Pool } from 'pg'

const app = express()
const PORT = 3000

const db = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'postgres',
  password: 'postgres',
  port: 5432
})

app.use(express.static('public'))
app.use(express.json())
app.use(cookieParser())

async function createTables() {
  await db.query(`
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      login TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      full_name TEXT NOT NULL,
      phone TEXT NOT NULL,
      email TEXT NOT NULL,
      role TEXT DEFAULT 'user'
    )
  `)

  await db.query(`
    CREATE TABLE IF NOT EXISTS orders (
      id SERIAL PRIMARY KEY,
      user_id INTEGER REFERENCES users(id),
      room TEXT NOT NULL,
      event_date TEXT NOT NULL,
      event_time TEXT NOT NULL,
      payment TEXT NOT NULL,
      status TEXT DEFAULT 'Новая',
      review TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `)

  await db.query(`
    INSERT INTO users (login, password, full_name, phone, email, role)
    VALUES ('Admin26', 'Demo20', 'Администратор', '+7(000)000-00-00', 'admin@mail.ru', 'admin')
    ON CONFLICT (login) DO NOTHING
  `)

  console.log('Таблицы готовы')
}

createTables()

app.post('/api/register', async (req, res) => {
  try {
    const { login, password, fullName, phone, email } = req.body

    const loginCheck = /^[A-Za-z0-9]{6,}$/
    const fullNameCheck = /^[А-Яа-яЁё\s]+$/
    const phoneCheck = /^(\+7\d{10}|\+7\(\d{3}\)\d{3}-\d{2}-\d{2})$/
    const emailCheck = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

    if (!login || !password || !fullName || !phone || !email) {
      return res.json({ success: false, message: 'Заполните все поля' })
    }

    if (!loginCheck.test(login)) {
      return res.json({ success: false, message: 'Логин: латиница и цифры, минимум 6 символов' })
    }

    if (password.length < 8) {
      return res.json({ success: false, message: 'Пароль должен быть минимум 8 символов' })
    }

    if (!fullNameCheck.test(fullName)) {
      return res.json({ success: false, message: 'ФИО должно содержать только кириллицу и пробелы' })
    }

    if (!phoneCheck.test(phone)) {
      return res.json({ success: false, message: 'Телефон должен быть в формате +79225340820 или +7(999)123-45-67' })
    }

    if (!emailCheck.test(email)) {
      return res.json({ success: false, message: 'Введите корректную электронную почту' })
    }

    await db.query(
      `INSERT INTO users (login, password, full_name, phone, email)
       VALUES ($1, $2, $3, $4, $5)`,
      [login, password, fullName, phone, email]
    )

    res.json({ success: true, message: 'Пользователь успешно создан' })
  } catch (error) {
    console.log(error)
    res.json({ success: false, message: 'Ошибка регистрации. Возможно, такой логин уже существует' })
  }
})

app.post('/api/login', async (req, res) => {
  try {
    const { login, password } = req.body

    if (!login || !password) {
      return res.json({ success: false, message: 'Введите логин и пароль' })
    }

    const result = await db.query(
      'SELECT * FROM users WHERE login = $1 AND password = $2',
      [login, password]
    )

    if (result.rows.length === 0) {
      return res.json({ success: false, message: 'Неверный логин или пароль' })
    }

    const user = result.rows[0]

    res.cookie('userId', user.id)
    res.cookie('role', user.role)

    if (user.role === 'admin') {
      return res.json({
        success: true,
        message: 'Вход администратора выполнен',
        page: '/admin.html'
      })
    }

    res.json({
      success: true,
      message: 'Вход выполнен',
      page: '/account.html'
    })
  } catch (error) {
    console.log(error)
    res.json({ success: false, message: 'Ошибка входа' })
  }
})

app.get('/api/logout', (req, res) => {
  res.clearCookie('userId')
  res.clearCookie('role')
  res.json({ success: true, message: 'Вы вышли из аккаунта' })
})

app.post('/api/order', async (req, res) => {
  try {
    const userId = req.cookies.userId

    if (!userId) {
      return res.json({ success: false, message: 'Сначала войдите в аккаунт' })
    }

    const { room, eventDate, eventTime, payment } = req.body
    const dateCheck = /^\d{2}\.\d{2}\.\d{4}$/

    if (!room || !eventDate || !eventTime || !payment) {
      return res.json({ success: false, message: 'Заполните все поля заявки' })
    }

    if (!dateCheck.test(eventDate)) {
      return res.json({ success: false, message: 'Дата должна быть в формате ДД.ММ.ГГГГ' })
    }

    await db.query(
      `INSERT INTO orders (user_id, room, event_date, event_time, payment)
       VALUES ($1, $2, $3, $4, $5)`,
      [userId, room, eventDate, eventTime, payment]
    )

    res.json({ success: true, message: 'Заявка успешно создана' })
  } catch (error) {
    console.log(error)
    res.json({ success: false, message: 'Ошибка создания заявки' })
  }
})

app.get('/api/my-orders', async (req, res) => {
  try {
    const userId = req.cookies.userId

    if (!userId) {
      return res.json([])
    }

    const result = await db.query(
      'SELECT * FROM orders WHERE user_id = $1 ORDER BY id DESC',
      [userId]
    )

    res.json(result.rows)
  } catch (error) {
    console.log(error)
    res.json([])
  }
})

app.post('/api/review', async (req, res) => {
  try {
    const userId = req.cookies.userId
    const { orderId, review } = req.body

    if (!userId) {
      return res.json({ success: false, message: 'Сначала войдите в аккаунт' })
    }

    if (!orderId || !review) {
      return res.json({ success: false, message: 'Введите отзыв' })
    }

    await db.query(
      `UPDATE orders 
       SET review = $1 
       WHERE id = $2 AND user_id = $3`,
      [review, orderId, userId]
    )

    res.json({ success: true, message: 'Отзыв сохранён' })
  } catch (error) {
    console.log(error)
    res.json({ success: false, message: 'Ошибка сохранения отзыва' })
  }
})

app.get('/api/admin/orders', async (req, res) => {
  try {
    if (req.cookies.role !== 'admin') {
      return res.json([])
    }

    const result = await db.query(`
      SELECT 
        orders.id,
        orders.room,
        orders.event_date,
        orders.event_time,
        orders.payment,
        orders.status,
        orders.review,
        users.full_name,
        users.phone,
        users.email
      FROM orders
      JOIN users ON orders.user_id = users.id
      ORDER BY orders.id DESC
    `)

    res.json(result.rows)
  } catch (error) {
    console.log(error)
    res.json([])
  }
})

app.post('/api/admin/status', async (req, res) => {
  try {
    if (req.cookies.role !== 'admin') {
      return res.json({ success: false, message: 'Нет доступа' })
    }

    const { orderId, status } = req.body

    if (!orderId || !status) {
      return res.json({ success: false, message: 'Не выбран статус' })
    }

    await db.query(
      'UPDATE orders SET status = $1 WHERE id = $2',
      [status, orderId]
    )

    res.json({ success: true, message: 'Статус изменён' })
  } catch (error) {
    console.log(error)
    res.json({ success: false, message: 'Ошибка изменения статуса' })
  }
})

app.listen(PORT, () => {
  console.log('Сервер работает на порту: ' + PORT)
})
