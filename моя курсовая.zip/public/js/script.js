const message = document.querySelector('#message')

function showMessage(text, type = 'error') {
  if (message) {
    message.textContent = text
    message.className = type
  }
}

async function postData(url, data) {
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(data)
  })

  return await response.json()
}

const registerForm = document.querySelector('#registerForm')

if (registerForm) {
  registerForm.addEventListener('submit', async (event) => {
    event.preventDefault()

    const login = document.querySelector('#registerLogin').value.trim()
    const password = document.querySelector('#registerPassword').value.trim()
    const fullName = document.querySelector('#registerFullName').value.trim()
    const phone = document.querySelector('#registerPhone').value.trim()
    const email = document.querySelector('#registerEmail').value.trim()

    const data = await postData('/api/register', {
      login,
      password,
      fullName,
      phone,
      email
    })

    showMessage(data.message, data.success ? 'success' : 'error')

    if (data.success) {
      registerForm.reset()

      setTimeout(() => {
        window.location.href = './login.html'
      }, 1000)
    }
  })
}

const loginForm = document.querySelector('#loginForm')

if (loginForm) {
  loginForm.addEventListener('submit', async (event) => {
    event.preventDefault()

    const login = document.querySelector('#loginLogin').value.trim()
    const password = document.querySelector('#loginPassword').value.trim()

    const data = await postData('/api/login', {
      login,
      password
    })

    showMessage(data.message, data.success ? 'success' : 'error')

    if (data.success) {
      setTimeout(() => {
        window.location.href = data.page
      }, 800)
    }
  })
}

const orderForm = document.querySelector('#orderForm')

if (orderForm) {
  orderForm.addEventListener('submit', async (event) => {
    event.preventDefault()

    const room = document.querySelector('#room').value
    const eventDate = document.querySelector('#eventDate').value.trim()
    const eventTime = document.querySelector('#eventTime').value
    const payment = document.querySelector('#payment').value

    const data = await postData('/api/order', {
      room,
      eventDate,
      eventTime,
      payment
    })

    showMessage(data.message, data.success ? 'success' : 'error')

    if (data.success) {
      orderForm.reset()
    }
  })
}

const myOrdersList = document.querySelector('#myOrdersList')

async function loadMyOrders() {
  if (!myOrdersList) return

  const response = await fetch('/api/my-orders')
  const orders = await response.json()

  myOrdersList.innerHTML = ''

  if (orders.length === 0) {
    myOrdersList.innerHTML = '<p>Заявок пока нет</p>'
    return
  }

  orders.forEach((order) => {
    const reviewBlock = order.status === 'Мероприятие завершено'
      ? `
        <textarea id="review-${order.id}" placeholder="Оставьте отзыв">${order.review || ''}</textarea>
        <button onclick="sendReview(${order.id})">Сохранить отзыв</button>
      `
      : '<p><b>Отзыв:</b> можно оставить после завершения мероприятия</p>'

    myOrdersList.innerHTML += `
      <div class="order-card">
        <h3>${order.room}</h3>
        <p><b>Дата:</b> ${order.event_date}</p>
        <p><b>Время:</b> ${order.event_time}</p>
        <p><b>Оплата:</b> ${order.payment}</p>
        <p><b>Статус:</b> ${order.status}</p>
        ${reviewBlock}
      </div>
    `
  })
}

loadMyOrders()

window.sendReview = async function (orderId) {
  const review = document.querySelector(`#review-${orderId}`).value.trim()

  const data = await postData('/api/review', {
    orderId,
    review
  })

  alert(data.message)
  loadMyOrders()
}

const adminOrdersList = document.querySelector('#adminOrdersList')

async function loadAdminOrders() {
  if (!adminOrdersList) return

  const response = await fetch('/api/admin/orders')
  const orders = await response.json()

  adminOrdersList.innerHTML = ''

  if (orders.length === 0) {
    adminOrdersList.innerHTML = '<p>Заявок нет или нет доступа</p>'
    return
  }

  orders.forEach((order) => {
    adminOrdersList.innerHTML += `
      <div class="order-card">
        <h3>${order.room}</h3>
        <p><b>ФИО:</b> ${order.full_name}</p>
        <p><b>Телефон:</b> ${order.phone}</p>
        <p><b>Email:</b> ${order.email}</p>
        <p><b>Дата:</b> ${order.event_date}</p>
        <p><b>Время:</b> ${order.event_time}</p>
        <p><b>Оплата:</b> ${order.payment}</p>
        <p><b>Текущий статус:</b> ${order.status}</p>
        <p><b>Отзыв:</b> ${order.review || 'Нет отзыва'}</p>

        <select id="status-${order.id}">
          <option value="Новая">Новая</option>
          <option value="Мероприятие назначено">Мероприятие назначено</option>
          <option value="Мероприятие завершено">Мероприятие завершено</option>
        </select>

        <button onclick="changeStatus(${order.id})">Изменить статус</button>
      </div>
    `
  })
}

loadAdminOrders()

window.changeStatus = async function (orderId) {
  const status = document.querySelector(`#status-${orderId}`).value

  const data = await postData('/api/admin/status', {
    orderId,
    status
  })

  alert(data.message)
  loadAdminOrders()
}

const logoutBtn = document.querySelector('#logoutBtn')

if (logoutBtn) {
  logoutBtn.addEventListener('click', async () => {
    await fetch('/api/logout')
    window.location.href = './index.html'
  })
}
